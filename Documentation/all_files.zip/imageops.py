"""
File for all kinds of image related functions.
"""

from PIL import Image
import PIL
import numpy as np

def open_image(path):
    """
    Opens image in correct format accepted by user facing functions.
    i.e. opens image as a np.uint8 numpy array [y, x, 3].
    """
    
    res = force_correct_format(path)
        
    return res

def force_correct_format(image):
    """
    Tries to force an image into format used by user facing functions.
    
    image -
      Accepts string; interprets it as a path to an image.
      Accepts PIL.Image.
      Accepts np.uint8 arrays of shapes [y, x], [y, x, 1], [y, x, 3] and [y, x, 4].
      
    Returns np.uint8 array of shape [y, x, 3].
    """
    if isinstance(image, str):
        res = image[:]
    else:
        res = image.copy()
    
    #Checking whether image is actually a path to an image.
    if isinstance(res, str):
        res = Image.open(res)
    
    #Checking whether an image is a PIL.Image.
    if isinstance(res, Image.Image):
        res = np.array(res)
         
    #Forcing there to be 3 color channels
    ##In case there's only one color channel broadcast it.
    if len(res.shape) == 2:
        res = res[:, :, np.newaxis] * np.ones(3)
        return
    
    if len(res.shape) == 3 and res.shape[2] == 1:
        res = res * np.ones(3)
        return res
    
    ##In case there's an alpha channel, drop it.
    ##Assumes the last channel is alpha.
    if len(res.shape) == 3 and res.shape[2] > 3:
        res = res[:, :, :3]
    
    return res
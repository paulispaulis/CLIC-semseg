"""
File is for models that turn images or text into embeddings.
Wrappers specifically for embedding purpouses.
"""

import torch
import torch.nn.functional as F
import numpy as np
import imageops

def _interpolate_np(array, new_x, new_y):
    """
    Bilinear interpolates array of shape [y, x, z] to [new_y, new_x, z].
    """
    array = torch.from_numpy(array).float()
    array = array.permute(2, 0, 1)
    array = array.unsqueeze(0)
    interpolated = F.interpolate(array, size=(new_y, new_x), mode='bilinear', align_corners=False)
    res = interpolated.squeeze(0).permute(1, 2, 0).numpy()
    
    return res


class ImageEmbedder():
    """
    Abstract class for image embedder.
    """
    
    def __init__(s):
        s.embedding_shape = None #Please put a list [height, width, embedding vector size] in here.
    
    def forward(s, image):
        """
        Function that takes an image and returns an embedding.
        
        Output should have shape s.embedding_shape.
        Output should be a numpy array.
        """
        raise NotImplemented()
        
    def forward_resize(s, image):
        """
        Function that takes an image, computes the embedding and interpolates it up to the size of the original image.
        Output is of shape [image height, image width, embbedding vector size].
        """
        image = imageops.force_correct_format(image)
        
        emb = s.forward(image)
        
        res = _interpolate_np(emb, image.shape[1], image.shape[0])

        return res
        
    def __str__(s):
        res = 'ImageEmbedder of class ' + str(s.__class__.__name__) + '\n'
        res+= 'Output shape: ' + str(s.embedding_shape) + '\n'
        
        return res
    
    
import dino
class DinoEmbedder(ImageEmbedder):
    """
    DinoV2 embedder.
    """
    def __init__(s, shape = 32, layer_count = 4, model_size = 'small'):
        super().__init__()
        
        s.model = dino.DinoModel()

        s.embedding_shape = [shape, shape, s.model.embedding_size * layer_count]
        
        s.layer_count = layer_count
        s.xshape = shape
    
    def forward(s, image):
        """
        I guess yolo, 
        By default the embedders gonna do dino.DinoModel.stretch_embed along the x axis, 
        then stretch it even more to the size of a square.
        
        Jank, but what's one to do.
        """
        emb = s.model.stretch_embed(image, xshape = s.xshape, layer_count = s.layer_count)
        
        #Interpolate
        res = _interpolate_np(emb, s.xshape, s.xshape)
        
        return res
    
    
import m2f 
class M2FEmbedder(ImageEmbedder):
    def __init__(s):
        s.model = m2f.M2FModel()
        
        s.embedding_shape = s.model.embedding_shape
        
    def forward(s, image):
        res = s.model.embed(image)
        
        return res
    
import sam
class SAMEmbedder(ImageEmbedder):
    def __init__(s):
        s.model = sam.SAMModel()
        
        s.embedding_shape = [64, 64, 256]
    
    def forward(s, image):
        res = s.model.embed(image)
        
        return res
    

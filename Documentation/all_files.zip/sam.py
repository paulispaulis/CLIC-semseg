"""
File for a general wrapper of SAM's functionality.
"""

import torch
from transformers import SamModel, SamProcessor
import device
from misc import tnp
import imageops

def _identify_structure(param):
    """
    This function is courtesy of ChatGPT.
    """
    # Check if it's a "point" - a list with exactly two numeric elements
    if isinstance(param, list) and len(param) == 2 and all(isinstance(x, (int, float)) for x in param):
        return "point"

    # Check if it's a "point list" - a list of "points"
    if isinstance(param, list) and all(isinstance(elem, list) and len(elem) == 2 and all(isinstance(x, (int, float)) for x in elem) for elem in param):
        return "point list"

    # If it's neither, return "invalid"
    return "invalid"


class SAMModel():
    def __init__(s, size = 'huge'):
        """
        Accepted sizes - "base", "large", "huge"
        """
        s.model = SamModel.from_pretrained("facebook/sam-vit-" + size).to(device.device)
        s.processor = SamProcessor.from_pretrained("facebook/sam-vit-" + size)
        
        s.embedding_size = 256 #It seems like this is true for all model sizes.
    
        s._has_embeddings = False
    
    def embed(s, image, ret = True):
        """
        Gets SAM embeddings for image.
        Caches result for use in SAMModel.get_masks().
        ret - boolean value of whether to return numpy array or not.
            defaults to True.
        
        Computes SAM embeddings for the image.
        Optionally returns embeddings as a numpy array of shape [64, 64, 256].
        """
        
        s.image = imageops.force_correct_format(image)
        
        #Preprocess
        s.inputs = s.processor(s.image, return_tensors="pt").to(device.device)
        
        #Get embeddings
        s.image_embeddings = s.model.get_image_embeddings(s.inputs["pixel_values"])
        
        s._has_embeddings = True
        
        if ret:
            res = tnp(s.image_embeddings.permute(0, 2, 3, 1))[0]
            return res
        
    def get_masks(s, points):
        """
        Gets masks at the provided points.
        You have to run SAMModel.embed() before using the SAMModel.get_masks() function.
        
        points - Either a list [x, y] containing a point in the image.
            Or a list of points, e.g. [[x1, y1], [x2, y2], [x3, y3]].
        
        Returns a tuple (masks, confidences):
            masks - bool numpy array of shape [3, image_y, image_x] if input is [x, y],
              [len(points), 3, image_y, image_x] if input is list of points.
              The numbers in the result are in the range [0..1].
            confidences - numpy array of shape [len(points), 3] with confidences for each SAM mask.
            
        note: SAM returns 3 masks per point, that's why the 3s appear in the output.
        """
        if not s._has_embeddings:
            raise Exception("No image has yet been embedded, but you're already asking for masks. Use SAMModel.embed(image) first.")
        
        #Corrently format input points for SAM.
        points_type = _identify_structure(points)
        if points_type == 'point':
            input_points = [[[points]]]
        elif points_type == 'point list':
            input_points = [[[point] for point in points]]
        else:
            raise ValueError("Expected points parameter to be a point [x, y] or list of points [[x1, y1], [x2, y2], ...], but got " + str(points))
        
        #Actually get masks
        s.inputs = s.processor(s.image, input_points = input_points, return_tensors="pt")
        s.inputs.pop("pixel_values", None) #I guess this indicates that the embeddings shouldn't be recomputed?
        s.inputs.update({"image_embeddings": s.image_embeddings}) #Magic line, I'm not gonna act like I understand what's going on here.
        
        with torch.no_grad():
            outputs = s.model(**s.inputs)
            masks = s.processor.image_processor.post_process_masks(outputs.pred_masks.cpu(), s.inputs["original_sizes"].cpu(), s.inputs["reshaped_input_sizes"].cpu())
            scores = outputs.iou_scores
        
        if points_type == 'point':
            res_masks = tnp(masks[0][0])
            res_scores = tnp(scores[0][0])
        elif points_type == 'point list':
            res_masks = tnp(masks[0])
            res_scores = tnp(scores[0])
        
        return (res_masks, res_scores)
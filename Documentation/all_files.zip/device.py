"""
File for setting the default device for all tensors.
"""

device = 'cpu'

def set_device(new_device):
    global device
    device = new_device
"""
File is for CS models.
Specifically the part that takes text embeddings and image embeddings and creates heatmaps.
"""
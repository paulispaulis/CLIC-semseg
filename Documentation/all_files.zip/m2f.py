"""
File for wrapping Mask2Former in a kinda general way.
"""

import torch
from transformers import AutoImageProcessor, Mask2FormerForUniversalSegmentation

from misc import tnp
import imageops
import device

class M2FModel():
    def __init__(s):
        super().__init__()
        
        s.embedding_shape = [96, 96, 256]
        
        s.model_name = "facebook/mask2former-swin-large-coco-panoptic"
        s.image_processor = AutoImageProcessor.from_pretrained(s.model_name)
        s.model = Mask2FormerForUniversalSegmentation.from_pretrained(s.model_name).to(device.device)
    
    def embed(s, image):
        image = imageops.force_correct_format(image)
        
        with torch.no_grad():
            #Embed
            inputs = s.image_processor(image, return_tensors="pt").to(device.device)
            outputs = s.model(**inputs)

            #Normalize
            norm = torch.norm(outputs[3][0], dim=0, p=2, keepdim=True)
            res = outputs[3][0] / norm
            
            #Turn to numpy in correct shape
            res = tnp(res.permute(1, 2, 0))
        
        return res
    
    def __str__(s):
        res = super().__str__()
        res += '\nModel name - ' + s.model_name
        
        return res
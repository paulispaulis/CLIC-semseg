"""
This file is just a wrapper for DinoV2 in a kinda general way.
Use the class DinoModel, to load a model.
Use DinoModel.pad_embed and DinoModel.stretch_embed to get embeddings.

Imma be honest I'm not sure how exactly Dino pre and post processing should work, but I hope this is good enough.
"""

import device
import torch
import torch.nn.functional as F
from transformers import AutoImageProcessor, Dinov2Model
import math

import imageops

class DinoModel():
    def __init__(s, size = 'small'):
        """
        size - size of model "small", "base", "large", "giant".
        """
        #Load the preprocessor provided by huggingface
        s.image_preprocessor = AutoImageProcessor.from_pretrained("facebook/dinov2-" + size)
        s.image_preprocessor.do_center_crop = False
        s.image_preprocessor.do_rescale = False
        s.image_preprocessor.do_resize = False
        s.image_preprocessor.rescale_factor = 0
        
        #Load the model
        s.model = Dinov2Model.from_pretrained("facebook/dinov2-" + size)
        s.model.to(device.device)
        
        s.embedding_size = s.model.config.hidden_size
        
    def _preprocess_image(s, image):
        res = s.image_preprocessor(image, return_tensors = 'pt')
        res = res.to(device.device)
        return res
    
    def _forward(s, inputs, layer_count = 4):
        """
        Takes preprocessed image and returns the last hidden states of dino concatenated.
        Returns torch tensor of shape [emb, shape, shape].
        """
        with torch.no_grad():
            outputs = s.model(**inputs, output_attentions = True, output_hidden_states = True)
            if layer_count == 1:
                res = outputs.last_hidden_state[0]
                emby = inputs['pixel_values'].shape[2]
                embx = inputs['pixel_values'].shape[3]
                res = res[1:].reshape([emby // 14, embx // 14, -1])
                res = res.numpy()
                return res
            else:
                res = outputs.hidden_states[-layer_count:]
                #Concat the different layers
                emby = inputs['pixel_values'].shape[2]
                embx = inputs['pixel_values'].shape[3]
                res = [r[0][:-1].reshape([emby // 14, embx // 14, -1]) for r in res]
                res = torch.cat(res, dim = 2)
                res = res.numpy()
                return res
    
    def _symmetrically_pad_tensor(s, input_tensor, target_size):
        """
        Pads a tensor symmetrically (or off by one) to the target size.

        Args:
        input_tensor (torch.Tensor): The input tensor with shape [1, 3, y, x].
        target_size (tuple): The target size as (dy, dx).

        Returns:
        torch.Tensor: The padded tensor.

        Coutersy of GPT4
        """
        # Current size
        _, _, y, x = input_tensor.shape

        # Calculate padding
        padding_y = max(target_size[0] - y, 0)
        padding_x = max(target_size[1] - x, 0)

        # Distribute padding symmetrically
        padding_left = padding_x // 2
        padding_right = padding_x - padding_left
        padding_top = padding_y // 2
        padding_bottom = padding_y - padding_top

        # Apply padding
        padded_tensor = F.pad(input_tensor, (padding_left, padding_right, padding_top, padding_bottom), mode='constant', value=0)

        return padded_tensor

    def pad_embed(s, image, shape = 32, layer_count = 4):
        """
        Pads image to a square with black pixels, then embeds it.
        
        Output shape will be [shape, shape, embedding vector size].
        """
        image = imageops.force_correct_format(image)
        image = image / 255
        
        ##Resize longest edge to edges of image.
        max_length = shape * 14
        resize_factor_x = max_length / image.shape[1]
        resize_factor_y = max_length / image.shape[0]
        resize_factor = min(resize_factor_x, resize_factor_y)
        
        new_x = round(image.shape[1] * resize_factor)
        new_y = round(image.shape[0] * resize_factor)
        
        image = torch.tensor(image, requires_grad = False, device = 'cpu').permute(2, 0, 1).unsqueeze(0)
        image = F.interpolate(image, [new_y, new_x], mode = 'bilinear').float()
        
        ##Padding
        image = s._symmetrically_pad_tensor(image, [max_length, max_length]).numpy()[0]
        
        ##
        inputs = s._preprocess_image(image)
        
        ##Run dino.
        res = s._forward(inputs, layer_count)
        
        return res
        
        
    
    def stretch_embed(s, image, xshape = None, yshape = None, layer_count = 4):
        """
        Slightly stretches the images so they fit the 14x14 grid.
        xshape - desired x dimension of embeddings.
        yshape - desired y dimension of embeddings.
        
        Both xshape and yshape cannot be set at the same time.
        If xshape is set, then output shape will be [y, xshape, embedding vector size].
        If yshape is set, then output shape will be [yshape, x, embedding vector size].
            x and y will be calculated automatically to minimize distorting the image. 
        """
        image = imageops.force_correct_format(image)
        image = image / 255
        
        if xshape is not None and yshape is not None:
            raise ValueError("Only xshape or yshape can be passed not both. The other side is calculated automatically.")
        
        elif xshape is not None:
            #Calc how much the x axis will be scaled by
            x_scale_factor = xshape * 14 / image.shape[1]
            
            #Calc optimal y size if not anchored to grid or pixel boundaries.
            y_optimal = image.shape[0] * x_scale_factor
            
            ##Calc optimal y size if anchored the 14 pixel grid.
            #Guess I'll try to minimize the abs(scaling_factor - 1).
            y_optimal_14 = y_optimal / 14
            #Calc distortions if rounded up and down.
            y_round_up = math.ceil(y_optimal_14)
            distortion_up = abs(y_optimal_14 / y_round_up - 1)
            y_round_down = math.floor(y_optimal_14)
            distortion_down = abs(y_optimal_14 / y_round_down - 1)
            
            if distortion_up < distortion_down:
                yshape = y_round_up
            else:
                yshape = y_round_down
        
        elif yshape is not None:
            #Analogous as for xshape.
            y_scale_factor = yshape * 14 / image.shape[0]
            
            x_optimal = image.shape[1] * y_scale_factor
            
            x_optimal_14 = x_optimal / 14
            
            x_round_up = math.ceil(x_optimal_14)
            distortion_up = abs(x_optimal_14 / x_round_up - 1)
            x_round_down = math.floor(x_optimal_14)
            distortion_down = abs(x_optimal_14 / x_round_down - 1)
            
            if distortion_up < distortion_down:
                xshape = x_round_up
            else:
                xshape = x_round_down
        
        new_x = xshape * 14
        new_y = yshape * 14
        
        image = torch.tensor(image, requires_grad = False, device = 'cpu').permute(2, 0, 1).unsqueeze(0)
        image = F.interpolate(image, [new_y, new_x], mode = 'bilinear').float()
        
        inputs = s._preprocess_image(image)
        
        ##Run dino.
        res = s._forward(inputs, layer_count)

        return res
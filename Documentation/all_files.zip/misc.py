"""
Random frequently recurring operations.
"""

def tnp(tens):
    """
    Creates copy of torch tensor as numpy array.
    """
    
    res = tens
    
    res = res.detach()
    
    res = res.to('cpu')
    
    res = res.numpy()
    
    return res
